import { Grid } from '@material-ui/core';
import React from 'react';
import './styles.scss';

const HeadingContent = ({title, description, isRequired , component}) => {
  return (
    <Grid container spacing={2} className="headingContent">
        <Grid item md={12} xs={12} className="headingContentDiv">
            <h6 className='title'>{title}{isRequired ? <span>*</span> : null}</h6>
            <div className='border' />
            <div style={{ paddingLeft:'8px', width:'100%', overflow:'hidden' }}>{component ? component : null}</div>
            <h6 className='description'>{description}</h6>
        </Grid>
    </Grid>
  )
}

export default HeadingContent;
