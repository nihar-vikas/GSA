import { Button, Grid } from '@material-ui/core';
import React, { useState } from 'react';
import './styles.scss';
import WarningImage from './icon-warning.svg';
import { BsArrowLeftShort, BsArrowRightShort } from 'react-icons/bs';

const PageLayout = ({
    currentPageNumber,
    pageCount,
    pageTitle,
    leftContent,
    rightContent,
    pageNavButtons,
    children
}) => {

  const [isExpanded, setIsExpanded] = useState(false);

  const toggleExpansion = () => {
        setIsExpanded(!isExpanded);
  };

  const text = leftContent?.description || '';
  const maxLength = 100;

  return (
    <Grid container spacing={2} className="pageLayout">
        <Grid item md={12} xs={12} className="pageLayoutHeader">
            <Grid className='pageCounterDiv'>
                <h6 className='pageCounter'>
                    <div className='currentPageCircle'>{currentPageNumber}</div>
                    &nbsp;of&nbsp;{pageCount}
                </h6>
            </Grid>
            <Grid className='pageTitleDiv'>
                <h6 className='pageTitle'>{pageTitle}</h6>
            </Grid>
        </Grid>
        <Grid item md={12} xs={12}>
            <Grid container spacing={2} className="pageBody">
                <Grid item md={2} xs={12} className="pageLeftContent">
                    <Grid className='pageLeftContentDiv'>
                        <h6 className='heading'><img src={WarningImage} alt="warningImage" />&nbsp;{leftContent?.heading || ''}</h6>
                        <h6 className='description'>{isExpanded ? text : text.slice(0, maxLength)}</h6>
                        {leftContent?.description?.length > maxLength ? <Button onClick={toggleExpansion} variant='text' className='readMoreButton'>{isExpanded ? ' Read Less' : ' Read More'}</Button> : null}
                    </Grid>
                    <div className='bottomBorder' />
                </Grid>
                <Grid item md={10} xs={12} className="pageRightContent">
                    <Grid container spacing={2} className="pageRightContentDiv">
                        <Grid item md={12} xs={12} className="pageRightContentHeader">
                            <h6 className='rightTitle'>{rightContent?.heading || ''}</h6>
                            <h6 className='rightDescription'>{rightContent?.description || ''}</h6>
                        </Grid>
                        <Grid item md={12} xs={12}>
                            {children}
                        </Grid>
                        <Grid item md={12} xs={12} className="buttonsDiv">
                            <Button className='prevButtons' variant='outlined' startIcon={<BsArrowLeftShort/>} onClick={pageNavButtons?.leftOnClick ? pageNavButtons?.leftOnClick : () => {}}>{pageNavButtons?.leftLabel ? pageNavButtons?.leftLabel : 'Previous'}</Button>
                            &nbsp;&nbsp;
                            <Button className='nextButtons' variant='contained' endIcon={pageNavButtons?.rightIcon ? pageNavButtons?.rightIcon  : <BsArrowRightShort/>} onClick={pageNavButtons?.rightOnClick ? pageNavButtons?.rightOnClick : () => {}}>{pageNavButtons?.rightLabel ? pageNavButtons?.rightLabel : 'Next'}</Button>
                        </Grid>
                    </Grid>
                </Grid>
            </Grid>
        </Grid>
    </Grid>
  )
}

export default PageLayout;
