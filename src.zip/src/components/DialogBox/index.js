import React from 'react';
import Dialog from '@material-ui/core/Dialog';
import Slide from '@material-ui/core/Slide';
import { Button, Grid, IconButton } from '@material-ui/core';
import CloseIcon from './close-Icon.svg';
import './styles.scss';

const Transition = React.forwardRef(function Transition(props, ref) {
  return <Slide direction="up" ref={ref} {...props} />;
});


const DialogBox = ({ title, open, handleClose, children, showFooter }) => {
  return (
    <Dialog
        open={open}
        TransitionComponent={Transition}
        keepMounted
        onClose={handleClose}
        fullWidth
        maxWidth="sm"
        aria-labelledby="alert-dialog-slide-title"
      >
        <Grid container className="dialog">
          <Grid item md={12} xs={12}>
            <Grid container className="dialogHeader">
              <Grid item md={12} xs={12} style={{ textAlign:'right' }}>
                <IconButton onClick={handleClose} size="small">
                  <img src={CloseIcon} alt="closeIcon" />
                </IconButton>
              </Grid>
              <Grid item md={12} xs={12}>
                <h6 className='dialogTitle'>{title}</h6>
              </Grid>
            </Grid>
            <Grid container className="dialogBody">
              <Grid item md={12} xs={12}>
                {children}
              </Grid>
            </Grid>
            {showFooter ? (
              <Grid container className="dialogFooter">
                <Button variant='text' className='cancelButton' onClick={handleClose}>Cancel</Button>
                &nbsp;&nbsp;&nbsp;
                <Button variant='contained' className='saveButton' onClick={handleClose}>Save</Button>
              </Grid>
            ) : null}
          </Grid>
        </Grid>
      </Dialog> 
  );
}

export default DialogBox;
