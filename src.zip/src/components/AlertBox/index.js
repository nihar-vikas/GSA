import { Grid } from '@material-ui/core';
import React from 'react';
import './styles.scss';
import ErrorIcon from './icon-error.svg';
import WarningIcon from './icon-warning.svg';


const AlertBox = ({ type , message }) => {
  return (
    <Grid container spacing={2} className="errorBox">
        <Grid item md={12} xs={12} className={`errorBoxMainDiv ${type === 'error' ? 'error' : 'warning'}`}>
            <Grid container spacing={2} className="errorBoxMainContent">
                <Grid item md={1} xs={1} style={{textAlign:'center'}}>
                    <img src={type === 'error' ? ErrorIcon : WarningIcon} alt="alertIcon" />
                </Grid>
                <Grid item md={11} xs={11}>                   
                    <h6 className='message'>{message}</h6>                    
                </Grid>
            </Grid>
        </Grid>
    </Grid>
  );
}

export default AlertBox;
