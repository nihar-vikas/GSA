import { Grid } from '@material-ui/core';
import React from 'react';
import PageLayout from '../../components/PageLayout';
import './styles.scss';

const DeliveryAddress = ({ pageNumber, handlePage, pageCount }) => {
  return (
  <Grid container spacing={2} className="deliveryAddress">
    <Grid item md={12} xs={12}>
      <PageLayout 
        currentPageNumber={pageNumber} 
        pageCount={pageCount} 
        pageNavButtons={{
          leftOnClick: () => handlePage('prev'),
          rightOnClick: () => handlePage('next')
        }}
        pageTitle="Delivery Address" 
        leftContent={{
          heading: 'This is an Urgent Requirement',
          description: 'The Express Desk processes vehicle orders for government agencies with urgent requirements. Agencies must justify the urgent and compelling reasons for using the Express Desk instead of waiting for the normal procurement cycle and delivery time to take place.',
        }}
        rightContent={{
          heading: 'Provide delivery and point of contact information ',
          description: 'Please provide information for the following adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam.',
        }}
      >
        
      </PageLayout>
    </Grid> 
  </Grid>  
  )
}

export default DeliveryAddress;
