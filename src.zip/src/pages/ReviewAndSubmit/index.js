import { Grid } from '@material-ui/core';
import React from 'react';
import PageLayout from '../../components/PageLayout';
import './styles.scss';
import { TiTick } from 'react-icons/ti';

const ReviewAndSubmit = ({ pageNumber, handlePage, pageCount }) => {
  return (
  <Grid container spacing={2} className="reviewAndSubmit">
    <Grid item md={12} xs={12}>
      <PageLayout 
        currentPageNumber={pageNumber} 
        pageCount={pageCount} 
        pageNavButtons={{
          leftOnClick: () => handlePage('prev'),
          rightOnClick: () => handlePage('next'),
          rightLabel: 'Submit to approver',
          rightIcon: <TiTick/>,
        }}
        pageTitle="Review and Submit" 
        leftContent={{
          heading: 'This is an Urgent Requirement',
          description: 'The Express Desk processes vehicle orders for government agencies with urgent requirements. Agencies must justify the urgent and compelling reasons for using the Express Desk instead of waiting for the normal procurement cycle and delivery time to take place.',
        }}
        rightContent={{
          heading: 'Review requisition summary and submit',
          description: 'Please review all entered information below prior to submitting your requisition. If you would like to make any edits, you may select the “Edit” link on the right of each section or navigate back within the requisition. ',
        }}
      >
        
      </PageLayout>
    </Grid> 
  </Grid>  
  )
}

export default ReviewAndSubmit;