import { Grid, MenuItem, TextField } from '@material-ui/core';
import React, { useState } from 'react'
import AlertBox from '../../components/AlertBox';
import DialogBox from '../../components/DialogBox';
import './styles.scss';

const FileUploadDialog = ({ open, handleClose }) => {
  const [note, setNote] = useState('');
  const [category, setCategory] = useState('');
  const [file, setFile] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const categoryList = [
      {
        value: 'USD',
        label: '$',
      },
      {
        value: 'EUR',
        label: '€',
      },
  ];


  const handleChange = (event) => {
    setCategory(event.target.value);
  };


  const handleFile = (event) => {
    const selected = event.target.files[0];
    if (selected) {
        if (selected.size > 10 * 1024 * 1024) {
            setErrorMessage('File size should be less than 10MB.');
        } else if (!['image/jpeg', 'application/pdf'].includes(selected.type)) {
            setErrorMessage('Only JPEG and PDF files are allowed.');
        } else {
            setFile(selected);
            setErrorMessage('');
        }
    }
  }

  const handleDrop = (event) => {
    event.preventDefault();
    const droppedFile = event.dataTransfer.files[0];
    handleFile(droppedFile);
  }

  const handleDragOver = (event) => {
      event.preventDefault();
  }


  return (
    <Grid container spacing={2}>
        <Grid item md={12} xs={12}>
            <DialogBox title="Upload new file" open={open} handleClose={handleClose} showFooter>
                <Grid container spacing={2} className="fileUploadModelContent">
                    <Grid item md={12} xs={12}>
                        <h6 className='formLabel'>Supporting file</h6>
                        <h6 className='formDescription'>Accepts .pdf and .jpeg files</h6>

                        {file ? (
                          <p>Selected file: {file.name}</p>
                        ) : (
                          <>
                            <label htmlFor="icon-button-file">
                                <div className='dropZone' onDrop={handleDrop} onDragOver={handleDragOver}>
                                    <h6 className='fileUploadLabel'>Drag files here or <span>choose from folder</span> (maximum size: 10 MB)</h6>
                                </div>
                            </label>
                            <input onChange={handleFile} value={file} accept=".pdf,.jpeg,.jpg,image/jpeg,application/pdf" className='uploadFileInput' id="icon-button-file" type="file" />
                          </>
                        )}
                        

                        {errorMessage ? (
                          <Grid style={{ paddingLeft: '8px', overflow:'hidden' }}>
                            <AlertBox type="error" message={errorMessage} />
                          </Grid>
                        ) : null}

                    </Grid>

                    <Grid item md={12} xs={12}>
                        <h6 className='formLabel'>Document Category <span>*</span></h6>
                        <TextField
                            id="category"
                            select
                            placeholder='-select-'
                            value={category}
                            variant="outlined"
                            fullWidth
                            onChange={handleChange}
                            className='docCatSelect'
                            style={{
                                padding: 0
                            }}
                            >
                            {categoryList.map((option) => (
                                <MenuItem key={option.value} value={option.value}>
                                  {option.label}
                                </MenuItem>
                            ))}
                        </TextField>

                        <div style={{ paddingLeft:'8px', margin: '1rem 0', overflow:'hidden' }}>
                          <AlertBox 
                            type="warning" 
                            message={
                                <h6 className="alertMessage">
                                    Help prevent a privacy incident by ensuring that any supporting document uploaded here does not contain <a href="/">personally identifiable information</a> (PII).
                                </h6>
                              }
                          />
                        </div>
                    </Grid>

                    <Grid item md={12} xs={12}>
                        <h6 className='formLabel'>Note</h6>
                        <h6 className='formDescription'>A few words to help identify this document</h6>
                        <TextField multiline minRows={5} fullWidth variant='outlined' value={note} onChange={(e) => setNote(e?.target?.value?.trimLeft()) }/>   
                        <h6 className='formDescription'>100 characters allowed</h6>
                    </Grid>

                </Grid>
            </DialogBox>
        </Grid>
    </Grid>
  );
}

export default FileUploadDialog;
