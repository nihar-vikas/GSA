import React, { useState } from 'react';
import { Button, Checkbox, FormControlLabel, Grid, TextField } from '@material-ui/core';
import HeadingContent from '../../components/HeadingContent';
import PageLayout from '../../components/PageLayout';
import RequirementsChecklist from './RequirementsChecklist';
import './styles.scss';
import AddIcon from './icon-old-plus.svg';
import DocumentsTable from './DocumentsTable';
import AlertBox from '../../components/AlertBox';
import FileUploadDialog from './FileUploadDialog';

const UrgentRequirement = ({ pageNumber, handlePage, pageCount }) => {
  const [justification, setJustification] = useState('');
  const [validation, setValidation] = useState(false);
  const [openUpload, setOpenUpload] = useState(false);

  const handleNext = () => {
    if(!justification) {
      setValidation(true);
    } 
    handlePage('next');
  }

  const handlePrev = () => {
    handlePage('prev');
  }


  return (
    <>
    <Grid container spacing={2} className="urgentRequirement">
      <Grid item md={12} xs={12}>
        <PageLayout 
          currentPageNumber={pageNumber} 
          pageCount={pageCount} 
          pageNavButtons={{
            leftOnClick: handlePrev,
            rightOnClick: handleNext
          }}
          pageTitle="Urgent Requirement justification" 
          leftContent={{
            heading: 'This is an Urgent Requirement',
            description: 'The Express Desk processes vehicle orders for government agencies with urgent requirements. Agencies must justify the urgent and compelling reasons for using the Express Desk instead of waiting for the normal procurement cycle and delivery time to take place.',
          }}
          rightContent={{
            heading: 'Provide justification and documentation for your urgent requirement',
            description: 'Exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.',
          }}
        >
          <Grid container spacing={2} className="urgentRequirementRightContent">
            <Grid md={8} xs={12} className="urgentRequirementRightContentDiv">
              <RequirementsChecklist />
            </Grid>

            <Grid md={8} xs={12} className="justifyUrgent">
              <HeadingContent isRequired title="Justification for Urgent and Compelling" description="Exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur." />
              <Grid className={validation && !justification ? 'errorValidationTextField' : ''}>
                {validation && !justification ? <h6 className='errorMessage'>This is a required field</h6> : null}
                <TextField multiline minRows={5} fullWidth className={`justifyTextarea ${validation && !justification ? 'error' : ''}`} variant='outlined' placeholder='Type justification here...' value={justification} onChange={(e) => setJustification(e?.target?.value?.trimLeft()) }/>   
              </Grid>       
            </Grid>

            <Grid md={8} xs={12} className="documentation">              
              <HeadingContent 
                 component={
                  (validation && !justification) ? 
                    <AlertBox 
                      type="error" 
                      message={
                      <Grid item md={11} xs={11} className="uploadDocErrorMainContent">
                          <h6 className='message'>This section is missing the following required file documents.</h6>
                          <ul className='messageItem'>
                              <li>Funding documentation</li>
                          </ul>
                          <h6 className='message'>In order to continue, please upload all required file documents, and be sure to select the corresponding document category for each.</h6>
                      </Grid>} /> : null} 
                isRequired 
                title="Documentation" 
                description="You may load multiple files; however, the combined size of all files cannot exceed 30 MB. File name will be converted to acceptable system files. All special characters will be removed. File names should be alpha numeric, and can also include underscores, commas periods and blank spaces. File types supported include Word, Excel, text, PDF, JPEG, etc."
              />         
            </Grid>

            <Grid md={8} xs={12} className="docTable">
              <Button onClick={() => setOpenUpload(true)} className='uploadButton' variant='outlined' startIcon={<img src={AddIcon} alt="addIcon" />}>Upload file</Button>
              <DocumentsTable />
              <Grid className='agreeCheckBox'>
                <FormControlLabel className='checkBoxLabel' control={<Checkbox color='primary' />} label="I hereby certify that I have uploaded all required documents for Urgent Requirement." />
              </Grid>
            </Grid>
          </Grid>
        </PageLayout>
      </Grid> 
    </Grid>
    <FileUploadDialog open={openUpload} handleClose={() => setOpenUpload(false)} />
    </>
  )
}

export default UrgentRequirement;
