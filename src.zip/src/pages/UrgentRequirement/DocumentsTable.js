import { Button, Grid, Menu, MenuItem, Table, TableBody, TableCell, TableContainer, TableHead, TableRow } from '@material-ui/core';
import React, { useState } from 'react';
import './styles.scss';
import { TbDots } from "react-icons/tb";
import { MdModeEditOutline } from 'react-icons/md';
import { AiFillCloseCircle } from 'react-icons/ai';
import { LuBoxSelect } from 'react-icons/lu';

const DocumentsTable = () => {
    const [anchorEl, setAnchorEl] = useState(null);

    const handleClick = (event) => {
        setAnchorEl(event.currentTarget);
      };
    
      const handleClose = () => {
        setAnchorEl(null);
      };

    const rows = [1,2,3,4];

    const open = Boolean(anchorEl);
    const id = open ? 'simple-popover' : undefined;

  return (
    <Grid container spacing={2} className="docTableMain">
        <Grid item md={12} xs={12} className="docTableDiv">
        <TableContainer>
            <Table aria-label="simple table">
                <TableHead className='tableHeader'>
                    <TableRow>
                        <TableCell className='tableHeaderCell' align='left'>File name</TableCell>
                        <TableCell className='tableHeaderCell' align="left">Document</TableCell>
                        <TableCell className='tableHeaderCell' align="left">Note</TableCell>
                        <TableCell className='tableHeaderCell' align="right">Actions</TableCell>
                    </TableRow>
                </TableHead>
                <TableBody>
                    {rows?.length > 0 ? (
                        rows.map((row) => (
                            <TableRow key={row} className="tableBodyCell">
                                <TableCell align='left' className='fileName'>File name</TableCell>
                                <TableCell align="left">Document</TableCell>
                                <TableCell align="left">Note</TableCell>
                                <TableCell align="right">                            
                                    <Button variant="text" onClick={handleClick}><TbDots className='actionButton'/></Button>                        
                                    <Menu
                                        id={id}
                                        anchorEl={anchorEl}
                                        keepMounted
                                        open={Boolean(anchorEl)}
                                        onClose={handleClose}
                                        anchorOrigin={{
                                            vertical: 'bottom',
                                            horizontal: 'right',
                                        }}
                                        transformOrigin={{
                                            vertical: 'top',
                                            horizontal: 'right',
                                        }}
                                        className="editPopoverMenu"
                                        >
                                        <MenuItem onClick={handleClose} className='editPopoverMenuItem'><MdModeEditOutline /> &nbsp; &nbsp; Edit file documentation</MenuItem>
                                        <MenuItem onClick={handleClose} className='editPopoverMenuItem'><AiFillCloseCircle/> &nbsp; &nbsp; Delete file</MenuItem>
                                    </Menu>
                                </TableCell>
                            </TableRow>
                        ))
                    ) : (
                        <TableRow>
                            <TableCell colSpan={4} align="center" className='emptyRecords'>
                                <h6 className='label'>No Files Uploaded</h6>
                                <LuBoxSelect className='dotedBox' />
                            </TableCell>
                        </TableRow>
                    )}
                
                </TableBody>
            </Table>
         </TableContainer>
        </Grid>
    </Grid>
  )
}

export default DocumentsTable;
