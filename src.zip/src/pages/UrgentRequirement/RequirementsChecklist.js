import { Grid } from '@material-ui/core';
import React from 'react';
import './styles.scss';

const RequirementsChecklist = () => {
  return (
    <Grid container spacing={2} className="requirementsChecklist">
        <Grid item md={12} xs={12} className="requirementsChecklistCard">
            <h6 className='title'>Requirements Checklist</h6>
            <ul className='unOrderList'>
                <li className='listItem'>Justification for Urgent and Compelling <span>(required)</span></li>
                <li className='listItem'>Source list <b>(if applicable)</b></li>
                <li className='listItem'>Brand name  justification <b>(if applicable)</b></li>
                <li className='listItem'>Sole source justification <b>(if applicable)</b></li>
                <li className='listItem'>Funding documentation <span>(required)</span> <a href="/">view details</a></li>
                <li className='listItem'>Other documentation</li>
            </ul>
        </Grid>
    </Grid>
  )
}

export default RequirementsChecklist;
