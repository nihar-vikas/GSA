import { Grid } from '@material-ui/core';
import React from 'react';
import PageLayout from '../../components/PageLayout';
import './styles.scss';

const AgencyInformation = ({ pageNumber, handlePage, pageCount }) => {
  return (
  <Grid container spacing={2} className="agencyInfo">
    <Grid item md={12} xs={12}>
      <PageLayout 
        currentPageNumber={pageNumber} 
        pageCount={pageCount} 
        pageNavButtons={{
          leftOnClick: () => handlePage('prev'),
          rightOnClick: () => handlePage('next')
        }}
        pageTitle="Agency Information" 
        leftContent={{
          heading: 'This is an Urgent Requirement',
          description: 'The Express Desk processes vehicle orders for government agencies with urgent requirements. Agencies must justify the urgent and compelling reasons for using the Express Desk instead of waiting for the normal procurement cycle and delivery time to take place.',
        }}
        rightContent={{
          heading: 'Provide agency information',
          description: 'Please provide information for your agency and financials. ',
        }}
      >
        
      </PageLayout>
    </Grid> 
  </Grid>    
  )
}

export default AgencyInformation;
