import { Grid } from '@material-ui/core';
import React, { useState } from 'react';
// import { BrowserRouter, Routes, Route } from "react-router-dom";
import AgencyInformation from './pages/AgencyInformation';
import DeliveryAddress from './pages/DeliveryAddress';
import ReviewAndSubmit from './pages/ReviewAndSubmit';
import UrgentRequirement from './pages/UrgentRequirement';


const App = () => {
  const [pageNumber, setPageNumber] = useState(2);
  const pageCount = 5;

  const handlePage = (type) => {
    console.log(type ,'ddddd');
    setPageNumber((prev) => (type === 'next' ? prev + 1 : prev - 1));
  }

  return (
    <Grid container spacing={2}>
        <Grid item md={12} xs={12}>
            {pageNumber === 2 ? <UrgentRequirement pageNumber={pageNumber} handlePage={handlePage} pageCount={pageCount} />: null}
            {pageNumber === 3 ? <AgencyInformation pageNumber={pageNumber} handlePage={handlePage} pageCount={pageCount} />: null}
            {pageNumber === 4 ? <DeliveryAddress pageNumber={pageNumber} handlePage={handlePage} pageCount={pageCount} />: null}
            {pageNumber === 5 ? <ReviewAndSubmit pageNumber={pageNumber} handlePage={handlePage} pageCount={pageCount} />: null}
            {/* <BrowserRouter>
                <Routes>
                    <Route path="/" exact element={<UrgentRequirement pageNumber={pageNumber} handlePage={handlePage} pageCount={pageCount} />} />
                    <Route path="/agencyInfo" exact element={<AgencyInformation pageNumber={pageNumber} handlePage={handlePage} pageCount={pageCount} />} />
                    <Route path="/delivery" exact element={<DeliveryAddress pageNumber={pageNumber} handlePage={handlePage} pageCount={pageCount} />} />
                    <Route path="/review" exact element={<ReviewAndSubmit pageNumber={pageNumber} handlePage={handlePage} pageCount={pageCount} />} />
                </Routes>
            </BrowserRouter> */}
        </Grid>
    </Grid>
  )
}

export default App;
